"""
Торговый бот XAUUSD для MetaTrader 5 (Windows).

Запуск в режиме наблюдения (без реальных ордеров):
    python scripts/bot.py --dry-run

Запуск в боевом режиме (DEMO счёт!):
    python scripts/bot.py

Параметры:
    --symbol      Символ (default: XAUUSD)
    --threshold   Порог вероятности сигнала (default: 0.70)
    --risk        Риск на сделку в % от баланса (default: 1.0)
    --tp          Тейк-профит в $ (default: 0.5)
    --sl          Стоп-лосс в $ (default: 0.5)
    --dry-run     Не открывать реальные ордера, только логировать
    --models-dir  Путь к папке models/ (default: ../models)
"""

import argparse
import json
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

# ── Путь к features.py (тот же каталог)
sys.path.insert(0, str(Path(__file__).resolve().parent))
from features import build_features, MIN_BARS  # noqa: E402

# ── Настройка логирования
LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(LOG_DIR / f"bot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log",
                            encoding="utf-8"),
    ],
)
log = logging.getLogger("bot")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="XAUUSD ML Bot")
    p.add_argument("--symbol", default="XAUUSD")
    p.add_argument("--threshold", type=float, default=0.70)
    p.add_argument("--risk", type=float, default=1.0,
                   help="Риск на сделку, %% от баланса")
    p.add_argument("--tp", type=float, default=0.5,
                   help="Тейк-профит в $ (цена)")
    p.add_argument("--sl", type=float, default=0.5,
                   help="Стоп-лосс в $ (цена)")
    p.add_argument("--dry-run", action="store_true",
                   help="Режим наблюдения: сигналы есть, ордеров нет")
    p.add_argument("--models-dir", default=None,
                   help="Путь к папке models/")
    return p.parse_args()


# ── Загрузка модели

def load_model(models_dir: Path, tag: str):
    model_path = models_dir / f"lgbm_{tag}.joblib"
    meta_path = models_dir / f"meta_{tag}.json"
    if not model_path.is_file():
        raise FileNotFoundError(f"Модель не найдена: {model_path}")
    model = joblib.load(model_path)
    with open(meta_path, encoding="utf-8") as f:
        meta = json.load(f)
    return model, meta


# ── Получение свечей из MT5

def get_bars(mt5, symbol: str, n: int = 200) -> pd.DataFrame:
    import MetaTrader5 as mt5lib
    rates = mt5lib.copy_rates_from_pos(symbol, mt5lib.TIMEFRAME_M1, 0, n)
    if rates is None or len(rates) == 0:
        raise RuntimeError(f"Нет данных MT5 для {symbol}")
    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time")
    df = df.rename(columns={"tick_volume": "volume"})[["open", "high", "low", "close", "volume"]]
    return df


# ── Расчёт размера лота

def calc_lot(mt5lib, symbol: str, sl_price: float, risk_pct: float) -> float:
    info = mt5lib.account_info()
    balance = info.balance
    sym_info = mt5lib.symbol_info(symbol)

    # Для XAUUSD: 1 лот = 100 унций, pip = 0.01
    # Стоимость 1 пипса на 1 лот = 0.01 * 100 = $1
    point = sym_info.point          # обычно 0.01 для XAUUSD
    lot_size = sym_info.trade_contract_size  # обычно 100

    sl_points = sl_price / point    # $0.50 / 0.01 = 50 points
    pip_value = point * lot_size    # $1.00 per lot per point

    risk_amount = balance * risk_pct / 100
    lot = risk_amount / (sl_points * pip_value)

    # Округляем до допустимого шага
    step = sym_info.volume_step     # обычно 0.01
    lot = round(lot / step) * step
    lot = max(sym_info.volume_min, min(sym_info.volume_max, lot))
    return lot


# ── Открытие ордера

def open_buy(mt5lib, symbol: str, lot: float, tp: float, sl: float,
             dry_run: bool) -> bool:
    ask = mt5lib.symbol_info_tick(symbol).ask
    sl_price = round(ask - sl, 2)
    tp_price = round(ask + tp, 2)

    if dry_run:
        log.info(f"[DRY-RUN] BUY {lot:.2f} лот @ {ask:.2f}  SL={sl_price}  TP={tp_price}")
        return True

    request = {
        "action": mt5lib.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": lot,
        "type": mt5lib.ORDER_TYPE_BUY,
        "price": ask,
        "sl": sl_price,
        "tp": tp_price,
        "deviation": 10,
        "magic": 20240001,
        "comment": "ml_bot",
        "type_time": mt5lib.ORDER_TIME_GTC,
        "type_filling": mt5lib.ORDER_FILLING_IOC,
    }
    result = mt5lib.order_send(request)
    if result.retcode == mt5lib.TRADE_RETCODE_DONE:
        log.info(f"Ордер открыт: BUY {lot:.2f} @ {ask:.2f}  SL={sl_price}  TP={tp_price}  ticket={result.order}")
        return True
    else:
        log.error(f"Ошибка ордера: {result.retcode}  {result.comment}")
        return False


# ── Проверка открытых позиций

def has_open_position(mt5lib, symbol: str) -> bool:
    positions = mt5lib.positions_get(symbol=symbol)
    return positions is not None and len(positions) > 0


# ── Основной цикл

def run(args: argparse.Namespace) -> None:
    import MetaTrader5 as mt5lib

    # Инициализация MT5
    if not mt5lib.initialize():
        log.error(f"MT5 не инициализирован: {mt5lib.last_error()}")
        sys.exit(1)
    log.info(f"MT5 подключён: {mt5lib.terminal_info().name}")
    log.info(f"Аккаунт: {mt5lib.account_info().login}  Баланс: ${mt5lib.account_info().balance:.2f}")

    # Загрузка модели
    models_dir = (
        Path(args.models_dir) if args.models_dir
        else Path(__file__).resolve().parent.parent / "models"
    )
    tag = f"M1_h5_tp{args.tp}_sl{args.sl}"
    model, meta = load_model(models_dir, tag)
    feature_cols = meta["feature_cols"]

    log.info(f"Модель загружена: {tag}  ROC-AUC={meta['roc_auc']}")
    log.info(f"Порог: {args.threshold}  TP={args.tp}  SL={args.sl}  Риск={args.risk}%")
    log.info(f"Режим: {'DRY-RUN (без ордеров)' if args.dry_run else '⚠️  LIVE'}")
    log.info("─" * 60)

    while True:
        try:
            now = datetime.now(timezone.utc)

            # Ждём начала новой минуты (первые 5 секунд)
            if now.second > 5:
                wait = 60 - now.second + 2
                time.sleep(wait)
                continue

            # Получаем свечи
            df = get_bars(mt5lib, args.symbol, n=MIN_BARS + 50)

            # Считаем признаки
            df = build_features(df)
            last = df.dropna().iloc[[-1]]  # последний полный бар

            if last.empty:
                log.warning("Не хватает данных для признаков")
                time.sleep(10)
                continue

            # Предсказание
            X = last[feature_cols]
            prob = model.predict_proba(X)[0, 1]
            signal = prob >= args.threshold

            bar_time = last.index[-1].strftime("%H:%M")
            log.info(f"{bar_time}  prob={prob:.3f}  {'>>> СИГНАЛ <<<' if signal else 'нет сигнала'}")

            if signal:
                if has_open_position(mt5lib, args.symbol):
                    log.info("Позиция уже открыта — пропускаем")
                else:
                    lot = calc_lot(mt5lib, args.symbol, args.sl, args.risk)
                    open_buy(mt5lib, args.symbol, lot, args.tp, args.sl, args.dry_run)

            # Пауза до следующей минуты
            time.sleep(55)

        except KeyboardInterrupt:
            log.info("Остановка бота (Ctrl+C)")
            break
        except Exception as e:
            log.error(f"Ошибка: {e}", exc_info=True)
            time.sleep(15)

    mt5lib.shutdown()
    log.info("MT5 отключён")


if __name__ == "__main__":
    args = parse_args()
    run(args)
